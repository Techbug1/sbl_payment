import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { paymentFormSchema } from "@shared/schema";
import { ZodError } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  app.post("/api/payment/initialize", async (req, res) => {
    try {
      const { amount, email } = paymentFormSchema.parse(req.body);
      const reference = `PAY_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
      
      const transaction = await storage.createTransaction({
        amount,
        email,
        reference,
      });

      res.json({
        reference: transaction.reference,
        amount: transaction.amount,
      });
    } catch (error) {
      if (error instanceof ZodError) {
        res.status(400).json({ message: error.errors[0].message });
      } else {
        res.status(500).json({ message: "Failed to initialize payment" });
      }
    }
  });

  app.post("/api/payment/verify/:reference", async (req, res) => {
    try {
      const { reference } = req.params;
      const { status } = req.body;

      const transaction = await storage.updateTransactionStatus(reference, status);
      
      res.json({
        status: transaction.status,
        reference: transaction.reference,
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to verify payment" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
