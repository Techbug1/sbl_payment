import { PaymentForm } from "@/components/payment-form";
import { Card, CardContent } from "@/components/ui/card";
import logo from "@/assets/Smart-Bookings-Coloured-166-600x245.png";

export default function PaymentPage() {
  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md mb-6">
        <img 
          src={logo} 
          alt="Smart Bookings Logo" 
          className="w-48 mx-auto mb-8"
        />
      </div>
      <Card className="w-full max-w-md border-green-800/20">
        <CardContent className="pt-6">
          <h1 className="text-2xl font-semibold text-center mb-6 text-green-900">
            Make Payment
          </h1>
          <PaymentForm />
        </CardContent>
      </Card>
    </div>
  );
}