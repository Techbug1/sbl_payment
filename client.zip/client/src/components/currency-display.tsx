import { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";

interface CurrencyDisplayProps {
  amountNGN: number;
}

export function CurrencyDisplay({ amountNGN }: CurrencyDisplayProps) {
  const [rates, setRates] = useState<{[key: string]: number}>({
    USD: 0,
    GBP: 0,
    EUR: 0
  });

  useEffect(() => {
    fetch("https://open.er-api.com/v6/latest/NGN")
      .then(res => res.json())
      .then(data => {
        setRates({
          USD: data.rates.USD,
          GBP: data.rates.GBP,
          EUR: data.rates.EUR
        });
      })
      .catch(err => console.error("Failed to fetch rates:", err));
  }, []);

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 my-6">
      {Object.entries(rates).map(([currency, rate]) => (
        <Card key={currency}>
          <CardContent className="pt-6">
            <p className="text-2xl font-bold text-center">
              {currency} {(amountNGN * rate).toFixed(2)}
            </p>
            <p className="text-sm text-muted-foreground text-center mt-2">
              Current {currency} equivalent
            </p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
