import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { PaymentFormData, paymentFormSchema } from "@shared/schema";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";

declare global {
  interface Window {
    PaystackPop: any;
  }
}

export function PaymentForm() {
  const { toast } = useToast();

  const form = useForm<PaymentFormData>({
    resolver: zodResolver(paymentFormSchema),
    defaultValues: {
      amount: 1000,
      email: "",
    },
  });

  const initializeMutation = useMutation({
    mutationFn: async (data: PaymentFormData) => {
      const res = await apiRequest("POST", "/api/payment/initialize", data);
      return res.json();
    },
  });

  const verifyMutation = useMutation({
    mutationFn: async ({ reference, status }: { reference: string; status: string }) => {
      const res = await apiRequest("POST", `/api/payment/verify/${reference}`, { status });
      return res.json();
    },
  });

  const onSubmit = async (data: PaymentFormData) => {
    try {
      if (!window.PaystackPop) {
        toast({
          variant: "destructive",
          title: "Payment Error",
          description: "Payment system not initialized properly. Please refresh the page.",
        });
        return;
      }

      const { reference } = await initializeMutation.mutateAsync(data);

      const handler = window.PaystackPop.setup({
        key: 'pk_test_5ba382f887de4ed70cb6a0a90cb889c9879d3261',
        email: data.email,
        amount: data.amount * 100,
        ref: reference,
        currency: 'NGN',
        channels: ['card', 'bank', 'ussd', 'qr', 'mobile_money', 'bank_transfer'],
        label: 'Payment',
        onClose: () => {
          toast({
            variant: "destructive",
            title: "Payment Cancelled",
            description: "You have cancelled the payment",
          });
        },
        callback: (response: any) => {
          verifyMutation.mutate(
            {
              reference: response.reference,
              status: response.status,
            },
            {
              onSuccess: () => {
                toast({
                  title: "Payment Successful",
                  description: "Your payment has been processed successfully",
                });
              },
              onError: (error) => {
                toast({
                  variant: "destructive",
                  title: "Verification Failed",
                  description: error instanceof Error ? error.message : "Failed to verify payment",
                });
              },
            }
          );
        },
      });

      handler.openIframe();
    } catch (error) {
      console.error("Payment error:", error);
      toast({
        variant: "destructive",
        title: "Payment Failed",
        description: error instanceof Error ? error.message : "There was an error processing your payment",
      });
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="email"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="text-green-900">Email Address</FormLabel>
              <FormControl>
                <Input
                  type="email"
                  placeholder="Enter your email"
                  className="border-green-800/20 focus:border-green-800 focus:ring-green-800"
                  {...field}
                />
              </FormControl>
              <FormMessage className="text-red-600" />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="amount"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="text-green-900">Amount (₦)</FormLabel>
              <FormControl>
                <Input
                  type="number"
                  placeholder="Enter amount"
                  className="border-green-800/20 focus:border-green-800 focus:ring-green-800"
                  {...field}
                  onChange={(e) => field.onChange(Number(e.target.value))}
                />
              </FormControl>
              <FormMessage className="text-red-600" />
            </FormItem>
          )}
        />

        <Button
          type="submit"
          className="w-full bg-green-800 hover:bg-green-900 text-white"
          disabled={initializeMutation.isPending}
        >
          {initializeMutation.isPending ? "Processing..." : "Pay Now"}
        </Button>
      </form>
    </Form>
  );
}